class Palin
{
    public static void main(String args[]) throws Exception
    {
        String str=new String("hello");
        StringBuilder str1= new StringBuilder(str);
        System.out.println(str1);
        StringBuilder str2= new StringBuilder(str);
        System.out.println(str1);
        System.out.println(str1==str2);  
        char[] str3=str.toCharArray();
        char[] str4=str.toCharArray();
        System.out.print(str3==str4);
     for(int i=0;i<str.length();i++)
     {
         for(int j=str.length;j>0;j++)
         {
             if(str[i]==str[j])
             {
                 i--;
                 j--;
            }else//  else(str[i]!=str[j])
             {
                 System.out.println("not plaindrome");
                 break;
             }
         }
         System.out.print("palindrome");
     }
    }
}