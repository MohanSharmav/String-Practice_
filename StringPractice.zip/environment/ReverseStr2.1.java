class ReverseStr2
{
    public static void main(String args[])
    {
         String str = new String("hello");
        System.out.println(str);
         char[] p=str.toCharArray();
         System.out.println(p);
         for(int i=p.length-1;i>=0;i--)
         {
             System.out.print(p[i]);
         }
    }
}