class PalindPerfect
{
    public static void main(String args[])
    {
        String str=new String ("sharma");
    int    x=str.length();
    System.out.println(" "+x);
        
    }
}