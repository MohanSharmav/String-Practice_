class Checky1
{
    public static void main(String args[])
    {
        String str1="hello";
        String str2="olleh";
    
       System.out.println(" "+str1+str2);
         System.out.println(str1.length()==str2.length());
       System.out.println((str1+str2));
      String str3=str1+str2;
      System.out.println(" nodu guru"+str3);
      System.out.println(str3.indexOf(str2)!=-1);
     System.out.println(str3.indexOf(str2));
    }
}
