class Summy10
{
    public static void main(String args[])
    {
        int[] arr= new int[]{1,2,3,4,5,7,8,9,10};
        int p=0;
        int i=0;
        while(i<=arr.length)
        {
            p=p+i;
             System.out.print(" "+ p);
            i++;
            
        }
        System.out.println();
      System.out.println(p);
    }
}