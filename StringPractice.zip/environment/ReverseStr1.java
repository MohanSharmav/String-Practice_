import java.io.*;
import java.util.*;
class ReverseStr1
{
    public static void display(int[] a)
    {
    StringBuilder sb= new StringBuilder();
    for (int val:a)
    {
        sb.append(val+ " ");
    }
    System.out.print(sb);
}
    
public static void reverse(int [] a)
{
    int i=0;
    int j=a.length;
    while (j<i)
    {
    int temp=a[i];
     a[i]=a[j];
    a[j]=temp;
    i++;
    j--;
    }
}
    
    
    public static void main(String args[]) throws Exception
    {
        BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
        int n= Integer.praseInt(br);
        int[] a=new int[n];
        for(int i=0;i<n;i++)
        {
            a[i] = Integer.parseInt(br.readLine());
        }
    }
}