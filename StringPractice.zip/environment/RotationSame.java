class RotationSame
{
//     public static Boolean cheeky(String str1,String str2)
//     {
//         for(int i=strr1.length();i>0;i++)
//         {
//             System.out.print(p[i]);
//         }
//     }
    
    public static void main(String args[])
    {
        String str01="hi";
        String str02="ih";
    //   ay();
    //     // checky(str1,str2);
    //       for(int i=str1.length();i>0;i++)
    //     {
    //         System.out.print(p[i]);
    //     } char[] str1=str01.toCharArray();
    //     char[] str2=str02.toCharArrar()
        StringBuilder str1=new StringBuilder(str01);
        str1.reverse();
       // System.out.println(str1);
        StringBuilder str2=new StringBuilder(str02);
       //  System.out.println(str2);
        System.out.println(str1.equals(str2));
        if (str1.equals(str2));
        {
            System.out.print("same str");
        }
    }
}