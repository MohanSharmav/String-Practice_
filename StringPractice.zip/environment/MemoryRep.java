class MemoryRep
{
    public static void main(String args[])
     {
    //     String str= new String("hello");
    //   String  c=str.hashcode();
    //     System.out.println(c);
        String s11= "a";
         System.out.println(Integer.toHexString(s11.hashCode()));
         
         String s9= new String("b");
         System.out.println(Integer.toHexString(s9.hashCode()));
          
          String s1= "abc";
    String s2 = new String("abc");
    String s3= "abc";

System.out.println("  "+ s1==s2);
System.out.println("  "+ s1.equals(s3));

    // System.out.println(Integer.toHexString(s1.hashCode()));
    // System.out.println(Integer.toHexString(s2.hashCode()));
    // System.out.println(Integer.toHexString(s3.hashCode()));
    // System.out.println(System.identityHashCode(s1));
    // System.out.println(System.identityHashCode(s2));
    // System.out.println(System.identityHashCode(s3));
    }
}