class Repeat
{
    public static charCount(String str)
    {
        for(int i=0;i<str.length();i++)
        {
            for(int j=str.length;j>0;j--)
            {
                if(str.charAt(i)==str.charAt(j))
                {
                    
                }
            }
        }
    }
    public static void main(String args[])
    {
        String str= new String("hello");
        charCount(str);
    }
}