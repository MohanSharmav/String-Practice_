import java.util.*;
import java.lang.*;
class Shuffle
{
    static boolean cheecky(String str1,String str2,String str3)
    {
    if(str3.length()!=str1.length()+str2.length())
    {
        return false;
    }
    int i=0,j=0,k=0;
    
    while(k!=str3.length())
    {
        if(i<str1.length() && str1.charAt(i)==str3.charAt(k))
        {
            i++;
        }
       else if(j<str2.length() && str2.charAt(j)==str3.charAt(k))
        {
            j++;
        }else{
            return false;
        }
        k++;
    }
    // int i=0;
    // while(i<str3.length())
    // {
    //     for(int j=0;j<str1.length();i++)
    //     {
    //         str3.charAt
    //     }
    // }
    if(i<str1.length() || j<str2.length())
    {
        return false;
    }
    return true;
    }

    public static void main(String[] args)
    {
    String str1="hello";
    String str2="hi";
    String[] str3={"hhelloi","hehillo"};
    // cheecky(str1,str2,str3)
    // {
    //     System.out.println("final string : "+str3," is shuffel with :"+str1," and :"+str2 );
    // }else{
    // System.out.println(" not shuffled string");
    // }
    for (String result : str3) 
    {
      if (cheecky(str1, str2, str3) == true){
        System.out.println(str3 + " is a valid shuffle of " + str1 + " and " +str2 );
    }
      else
      {
        System.out.println(str3 + " is not  valid shuffle of " + str1 + " and " + str2);
      }
    }
    }}
    