class ReverseStr
{
    public static void main(String args[])
    {
        String  str=new String("hello");
        int i=str.length();
        while (i>=0)
        {
            StringBuilder a=new StringBuilder();
            System.out.print(str(i));
            i--;
        }
    }
}