class Ify
{
    public static void main(String args[])
    {
        int i=0;
        if(i==0)
         System.out.print("i same");
                      else
             System.out.print("not");
    }
}